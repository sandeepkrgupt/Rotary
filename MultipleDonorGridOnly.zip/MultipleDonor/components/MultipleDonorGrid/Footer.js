import React from 'react';
import styled from 'styled-components';
import {
  bp,
  fieldLabel,
  inputStyling,
  pxToRem,
} from 'styles';
import * as locale from 'locale';
const Drupal = locale.Drupal;

const MultipleDonorGridFooterContainer = styled.div`
  align-items: flex-end;
  display: flex;
  flex-direction: column;
  margin-bottom: ${pxToRem(30)};
`;

const AmountTotalContainer = styled.div`
  cursor: default;
  width: ${pxToRem(105)};
  ${bp('xs_up')`
    width: ${pxToRem(65)};
  `};
  ${bp('xs_landscape_up')`
    width: ${pxToRem(80)};
  `};
  ${bp('s_up')`
    width: ${pxToRem(112)};
  `};
`;

const AmountTotalLabel = styled.div`
  ${fieldLabel()}
`;

const CurrencyCode = styled.span`
  font-weight: 400;
`;

const AmountTotal = styled.div`
  ${inputStyling()}
  display: block;
  line-height: 28px;
  padding: 0.3rem 0.295rem;
  overflow:hidden;
  text-overflow:ellipsis;
`;
 // padding: ${pxToRem(5)} ${pxToRem(15)};
const MultipleDonorGridFooter = ({ currencyCode, amount, rows }) => {
  let amountTotalText = "";
  let amountTotalNum = 0;
  let nonAutoInsertedRows = rows.filter(row => !row.isAutoInserted);
  let noError = nonAutoInsertedRows.every(value => value.errorMessage.err_amount === undefined)
  if(noError){
    amountTotalNum = nonAutoInsertedRows.reduce((acc, cur) => acc+Number(cur.amount), 0);
  }

  if(amountTotalNum > 0) {
    amountTotalText = amountTotalNum;
  } else {
    amountTotalText = "";
  }

return (
  <MultipleDonorGridFooterContainer>
    <AmountTotalContainer>
      <AmountTotalLabel>
        {`${Drupal.t('Total')}`} <CurrencyCode>({currencyCode})</CurrencyCode>
      </AmountTotalLabel>
      <AmountTotal title={amountTotalText}>
        {amountTotalText}
      </AmountTotal>
    </AmountTotalContainer>
  </MultipleDonorGridFooterContainer>
)
};

export default MultipleDonorGridFooter;