import React from "react";
import TextInput from 'Form/components/TextInput';
import Select from 'Form/components/Select';
import styled from 'styled-components';
import throbber from '!!url-loader!assets/throbber.gif';
import { typeOptions } from '../../utils/utils.mulitpleDonor'
import {
  CloseGraphic,
  CloseIcon,
  ButtonWrapper
} from 'globalStyles';

const LoadingVisual = styled.div.attrs({ className: 'react-throbber__visual' })`
  background: url(${throbber}) no-repeat;
  height: 32px;
  margin: -0.3rem auto 0.4rem;
  width: 32px;
`;
const MultipleDonorGridRow = props => {
  const {
    multipleDonorConfig,
    gridRowData,
    rowsCount,
    onChange,
    onClear,
    onDelete,
    onBlur
  } = props;

  let topErrorBorder = '';
  let atLeastOneErr = gridRowData.errorMessage.err_id || gridRowData.errorMessage.err_amount;

  if (atLeastOneErr) {
    topErrorBorder = ' top-error-border';
  }

  return (
    <div className={gridRowData.errorMessage.err_amount != "" && (atLeastOneErr) ? "no-top-border" : "row-container"}>
      <div className={"mdg-row flex-host" + topErrorBorder}>
        <div className="mdg-col data">
          <Select
            id="type"
            options={typeOptions}
            value={gridRowData.selectedType}
            onChange={(event) => {
              onChange({ selectedType: event.value });
            }}
          />
        </div>
        <div className="mdg-col data">
          {gridRowData.selectedType ?
            <div className={(gridRowData.errorMessage.err_id) ? 'mdg-error-border-id' : ''}>
              <TextInput
                maxLength="12"
                value={gridRowData.id}
                type="text"
                onChange={event => {
                  onChange({ id: event.target.value });
                }}
                onBlur={event => {
                  onBlur({ donorId: event.target.value.trim() });
                }}
              />
            </div> :
            <label></label>}
        </div>
        <div className="mdg-col data" title={(typeof (gridRowData.first_name || gridRowData.last_name) != "undefined") ? `${gridRowData.first_name} ${gridRowData.last_name}` : ""}>
          <label>
            {gridRowData.isLoading ? <LoadingVisual /> : (typeof (gridRowData.first_name || gridRowData.last_name) != "undefined") ? `${gridRowData.first_name} ${gridRowData.last_name}` : ""}
          </label>
        </div>
        <div className="mdg-col data">
          {(gridRowData.selectedType && gridRowData.id && (gridRowData.first_name || gridRowData.last_name)) ?
            <div className={(gridRowData.amount != "" && gridRowData.errorMessage.err_amount) ? 'mdg-error-border-id' : ''}>
                <TextInput
                  value={gridRowData.amount}
                  type="text"
                  onChange={event => {
                    onChange({ amount: event.target.value });
                  }}
                />
            </div> :
            <label className="mdg-label-readonly">{gridRowData.amount}</label>}
        </div>
        {!gridRowData.isAutoInserted && (
          <div className="mdg-actions">
            <ButtonWrapper
              onClick={() => {
                if (rowsCount === multipleDonorConfig.minRows) {
                  onClear();
                } else {
                  onDelete();
                }
              }}
            >
              <CloseGraphic><CloseIcon /></CloseGraphic>
            </ButtonWrapper>
          </div>
        )}
      </div>
      {Object.keys(gridRowData.errorMessage).map(err => {
        return <div className="mdg-error">{gridRowData.errorMessage[err]}</div>
      })}
    </div>
  );
};

export default MultipleDonorGridRow;