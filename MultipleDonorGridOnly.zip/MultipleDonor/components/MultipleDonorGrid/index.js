import React from "react";
import MultipleDonorGridRow from './GridRow'
import Header from './Header';

const MultipleDonorGrid = props => {
  const {
    currencyCode,
    multipleDonorConfig,
    gridData,
    onChange,
    onClear,
    onDelete,
    onBlur
  } = props;
  return (
    <div className="mdg-container flex-host">
      <Header currencyCode={currencyCode} />
      <div className="mdg-body">
        {
          gridData.map((gd,i) => (
            <MultipleDonorGridRow
              key={i}
              multipleDonorConfig={multipleDonorConfig}
              rowsCount={gridData.length}
              gridRowData={gd}
              onChange={change => {
                onChange({ index: i, change });
              }}
              onClear={() => {
                onClear({ index: i });
              }}
              onDelete={() => {
                onDelete({ index: i });
              }}
              onBlur={data => {
                onBlur({ index: i, data });
              }}
            />
            ))
          }
      </div>
    </div>
  );
};

export default MultipleDonorGrid;