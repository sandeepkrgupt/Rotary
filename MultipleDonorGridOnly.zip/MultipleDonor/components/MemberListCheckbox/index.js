import React from 'react';
import {
  CheckboxListItemWithError,
} from 'Form/components/Checkbox';
import * as locale from 'locale';
import styled from 'styled-components';

const Drupal = locale.Drupal;

const MemberListCheckboxWrapper = styled.div.attrs({
  className: 'memberlist-checkbox-wrapper',
})``;

const MemberListCheckbox = ({ memberListVisibility, toggleMemberListVisibility, clubName }) => {
  
  return (
    <MemberListCheckboxWrapper>
      <CheckboxListItemWithError
        id="MemberList"
        checked={memberListVisibility}
        onChange={toggleMemberListVisibility}
        label={Drupal.t('Add Rotary club of @clubName member list', { '@clubName': `${clubName}`})}
        errorMsg={Drupal.t(
          'Error for member list',
        )}
      />
    </MemberListCheckboxWrapper>
  );
};

export default MemberListCheckbox;