import React from 'react';
import styled from 'styled-components';
import MultipleDonorGridFooter from './components/MultipleDonorGrid/Footer';
import MultipleDonorGrid from './components/MultipleDonorGrid/index';
import MemberListCheckbox from './components/MemberListCheckbox/index';
import { getDefaultRows, validators } from './utils/utils.mulitpleDonor';
import { fetchDonorNameByTypeAndMemberId } from 'utils';
import { fetchMemberListById } from 'utils';
import {
  color,
  pxToRem
} from 'styles';
import GlobalStyles from 'globalStyles';
import * as locale from 'locale';

const Drupal = locale.Drupal;
const Container = styled.div.attrs({ className: 'multipledonorgrid__container' })`
`;
const MultipleDonorHeading = styled.div`
  border-bottom: 1px solid ${color.navy};
  color: ${color.navy};
  font-size: ${pxToRem(24)};
  font-weight: 300;
  line-height: 90%;
  margin-bottom: 30px;
  padding-bottom: 6px;
  padding-top: 10px;
`;
class MultipleDonor extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      gridData: getDefaultRows(),
      multipleDonorConfig: { minRows: 1 },
      memberListVisibility: false
    }
    this.getDonorName = this.getDonorName.bind(this);
    this.getDonorList = this.getDonorList.bind(this);
    this.toggleMemberListVisibility = this.toggleMemberListVisibility.bind(this);
    this.isAtLeastOneRowComplete = this.isAtLeastOneRowComplete.bind(this);
  }
  isAtLeastOneRowComplete() {
    return this.state.gridData.find(gdr =>
      gdr.id &&
      validators.isValidId(gdr.id) &&
      gdr.selectedType &&
      (gdr.first_name || gdr.last_name) &&
      gdr.amount &&
      validators.isValidAmount(gdr.amount) &&
      !gdr.isLoading &&
      !gdr.isAutoInserted
    ) !== undefined
  }
  isAtLeastOneRowIncomplete() {
    return this.state.gridData.find(gdr =>
      Object.keys(gdr.errorMessage).length > 0
    ) !== undefined
  }
  componentDidMount() {
    this.props.setMultipleDonorError(true, false);
  }
  /** Get Member Lists By Club_Id */
  toggleMemberListVisibility() {
    this.getDonorList(this.props.clubId, this.props.config.api_url);
    this.setState({
      memberListVisibility: !this.state.memberListVisibility,
    });
  };

  getDonorList(clubId, api_url) {
    if (this.state.memberListVisibility) {
      return;
    }
    if (clubId !== undefined && clubId.length !== 0) {
      fetchMemberListById(api_url, clubId)
        .then(data => {
          if (data !== undefined && data.length !== 0) {
            data.map((gd) => {
              this.state.gridData.unshift({
                id: gd.member_id,
                first_name: gd.first_name,
                last_name: gd.last_name,
                amount: "",
                selectedType: "Individual",
                isAutoInserted: false,
                errorMessage: {},
                isLoading: false
              });
              this.setState({
                gridData: this.state.gridData
              });
            })
          }
        })
        .catch(err => {
          console.log(err);
        })
        .finally(() => {
          this.setState({
            gridData: this.state.gridData,
          });
        });
    }
  }
  /** ----------- */
  getDonorName(type, id, api_url, index) {
    if (type != "" && id.length !== 0) {
      this.state.gridData[index].isLoading = true;
      this.setState({
        gridData: this.state.gridData,
      });

      fetchDonorNameByTypeAndMemberId(api_url, type, id)
        .then(data => {
          if (data.StatusCode == 200) {
            delete this.state.gridData[index].errorMessage.err_id;
            this.state.gridData[index].first_name = data.Name;
          } else {
            this.state.gridData[index].errorMessage["err_id"] = data.Message;
            this.state.gridData[index].first_name = "";
            this.state.gridData[index].last_name = "";
          }
        })
        .catch((data) => {
          this.state.gridData[index].errorMessage["err_id"] = data;
          this.state.gridData[index].first_name = "";
          this.state.gridData[index].last_name = "";
        }).finally(() => {
          this.state.gridData[index].isLoading = false;
          this.setState({
            gridData: this.state.gridData,
          },
            () => {
              if (!this.isAtLeastOneRowComplete() || this.isAtLeastOneRowIncomplete()) {
                this.props.setMultipleDonorError(true, true);
              } else {
                this.props.setMultipleDonorError(false, true);
              }
            });
        });
    }
  }

  render() {
    const {
      currency,
      config,
      individual,
      organization,
      clubName,
      clubId,
      multipleDonorError,
      setMultipleDonorObject,
    } = this.props;

    const api_url = config.api_url;
    const currencyCode = currency.code && currency.code.toUpperCase();
    return (
      <Container id="multiple-donor-grid">
        <MultipleDonorHeading>
          {Drupal.t('Multiple donors')}
        </MultipleDonorHeading>
        {((individual.type == "Individual" || organization.type == "Rotary Club") && (clubName != "Rotary International" && clubId != 1)) &&
          <MemberListCheckbox
            memberListVisibility={this.state.memberListVisibility}
            toggleMemberListVisibility={this.toggleMemberListVisibility}
            clubName={clubName}
          />
        }
        {
          (!this.isAtLeastOneRowComplete() &&
            (this.props.multipleDonorError.status && this.props.multipleDonorError.visibility) && (
              <div className="mdg-empty-row-error-msg">
                <label>Please complete at least one row.</label>
              </div>
            ))}
        <GlobalStyles>
          <MultipleDonorGrid
            currencyCode={currencyCode}
            multipleDonorConfig={this.state.multipleDonorConfig}
            gridData={this.state.gridData}
            onChange={({ index, change }) => {
              setMultipleDonorObject(this.state.gridData);
              this.state.gridData[index] = {
                ...this.state.gridData[index],
                ...change
              };
              if (change.id !== undefined) {
                this.state.gridData[index].first_name = "";
                this.state.gridData[index].last_name = "";
                if (validators.isValidId(change.id)) {
                  delete this.state.gridData[index].errorMessage.err_id;
                } else {
                  this.state.gridData[index].errorMessage["err_id"] = 'Please enter a numeric value that does not start with zero.';
                }
              } else if (change.amount !== undefined) {
                if (change.amount == "" || validators.isValidAmount(change.amount)) {
                  delete this.state.gridData[index].errorMessage.err_amount;
                } else {
                  this.state.gridData[index].errorMessage["err_amount"] = 'For amount field, please enter a numeric value that does not start with zero.';
                }
              }

              if (this.state.gridData[index].isAutoInserted === true) {
                delete this.state.gridData[index].isAutoInserted;
              }
              let last = this.state.gridData[this.state.gridData.length - 1];
              if (last.isAutoInserted !== true) {
                this.state.gridData.push({
                  ...getDefaultRows(1)[0]
                });
              }
              this.setState({
                gridData: this.state.gridData
              }, () => {
                if (!this.isAtLeastOneRowComplete() || this.isAtLeastOneRowIncomplete()) {
                  this.props.setMultipleDonorError(true, true);
                } else {
                  this.props.setMultipleDonorError(false, true);
                }
              });
              if (change.selectedType !== undefined && change.selectedType.length !== 0 && validators.isValidId(this.state.gridData[index].id)) {
                this.getDonorName(this.state.gridData[index].selectedType, this.state.gridData[index].id, api_url, index);
              }
            }}
            onClear={({ index }) => {
              this.state.gridData[index] = getDefaultRows(1)[0];
              this.setState({
                gridData: this.state.gridData
              })
            }}
            onDelete={({ index }) => {
              const remainingRows = this.state.gridData.filter((td, i) => i !== index);
              setMultipleDonorObject(remainingRows);
              this.setState({
                gridData: remainingRows
              }, () => {
                if (!this.isAtLeastOneRowComplete() || this.isAtLeastOneRowIncomplete()) {
                  this.props.setMultipleDonorError(true, true);
                } else {
                  this.props.setMultipleDonorError(false, true);
                }
              });
            }}
            onBlur={({ index, data }) => {
              if (data.donorId && this.state.gridData[index].errorMessage.err_id === undefined) {
                this.getDonorName(this.state.gridData[index].selectedType, data.donorId, api_url, index);
              }
            }}
            multipleDonorError={this.props.multipleDonorError}
          />
        </GlobalStyles>
        <MultipleDonorGridFooter currencyCode={currencyCode} amount={""} rows={this.state.gridData} />
      </Container>
    );
  }
}

export default MultipleDonor;