import React from 'react';
import {
  CheckboxListItemWithError,
} from 'Form/components/Checkbox';
import * as locale from 'locale';

const Drupal = locale.Drupal;

const MultipleDonorCheckbox = ({
  multipleDonorVisibility,
  toggleMultipleDonorVisibility
}) => {
  return (
    <CheckboxListItemWithError
      id="MultipleDonor"
      checked={multipleDonorVisibility}
      onChange={toggleMultipleDonorVisibility}
      label={Drupal.t('This donation is from multiple donors')}
      errorMsg={Drupal.t(
        'Error for multiple donors',
      )}
    />
  );
};

export default MultipleDonorCheckbox;