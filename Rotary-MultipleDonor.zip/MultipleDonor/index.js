import React from 'react';
import styled from 'styled-components';
import MultipleDonorGridFooter from './components/MultipleDonorGrid/Footer';
import MultipleDonorGrid from './components/MultipleDonorGrid/index';
import { getDefaultRows } from './utils/utils.mulitpleDonor';
import { fetchDonorNameByTypeAndMemberId } from 'utils';
import {
  color,
  pxToRem
} from 'styles';
import GlobalStyles from 'globalStyles';
import * as locale from 'locale';

const Drupal = locale.Drupal;
const Container = styled.div.attrs({ className: 'multipledonorgrid__container' })`
`;
const MultipleDonorHeading = styled.div`
  border-bottom: 1px solid ${color.navy};
  color: ${color.navy};
  font-size: ${pxToRem(24)};
  font-weight: 300;
  line-height: 90%;
  margin-bottom: 30px;
  padding-bottom: 6px;
  padding-top: 10px;
`;
class MultipleDonor extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      gridData: getDefaultRows(),
      multipleDonorConfig: { minRows: 1 }
    }
    this.getDonorName = this.getDonorName.bind(this);
  }

  getDonorName(type, id, api_url, index) {
    if (type != "" && id.length !== 0) {
      this.state.gridData[index].isLoading = true;
      this.setState({
        gridData: this.state.gridData,
      });

      fetchDonorNameByTypeAndMemberId(api_url, type, id)
        .then(data => {
          if (data.StatusCode == 200) {
            this.state.gridData[index].error = false;
            this.state.gridData[index].errorMessage[0] = '';
            this.state.gridData[index].name = data.Name;
          } else {
            this.state.gridData[index].error = true;
            this.state.gridData[index].errorMessage[0] = data.Message;
            this.state.gridData[index].name = "";
          }
        })
        .catch((data) => {
          this.state.gridData[index].error = true;
          this.state.gridData[index].errorMessage[0] = data;
          this.state.gridData[index].name = "";
        }).finally(() => {
          this.state.gridData[index].isLoading = false;
          this.setState({
            gridData: this.state.gridData,
          });
        });
    }
  }
  render() {
    const {
      currency,
      config
    } = this.props;
    const api_url = config.api_url;
    const currencyCode = currency.code && currency.code.toUpperCase();
    return (
      <Container id="multiple-donor-grid">
        <MultipleDonorHeading>
          {Drupal.t('Multiple donors')}
        </MultipleDonorHeading>
        <GlobalStyles>
          <MultipleDonorGrid
            currencyCode={currencyCode}
            multipleDonorConfig={this.state.multipleDonorConfig}
            gridData={this.state.gridData}
            onChange={({ index, change }) => {
              this.state.gridData[index] = {
                ...this.state.gridData[index],
                ...change
              };
              if(change.id) {
                if(/^[1-9][0-9]{0,11}$/g.test(change.id) === true) {
                  this.state.gridData[index].errorMessage[0] = '';
                  this.state.gridData[index].setMdnIdError = false;
                } else {
                  this.state.gridData[index].errorMessage[0] = 'Please enter a numeric value that does not start with zero.';
                  this.state.gridData[index].setMdnIdError = true;
                }
              }
              if (change && change.amount) {
                if(/^[1-9][0-9]{0,}$/g.test(change.amount) === true) {
                  this.state.gridData[index].errorMessage[1] = '';
                  this.state.gridData[index].setMdnAmountError = false;
                } else {
                  this.state.gridData[index].errorMessage[1] = 'For amount field, please enter a numeric value that does not start with zero.';
                  this.state.gridData[index].setMdnAmountError = true;
                }
              }
              
              if (this.state.gridData[index].isAutoInserted === true) {
                delete this.state.gridData[index].isAutoInserted;
              }
              let last = this.state.gridData[this.state.gridData.length - 1];
              if (last.isAutoInserted !== true) {
                this.state.gridData.push({
                  ...getDefaultRows(1)[0]
                });
              }
              this.setState({
                gridData: this.state.gridData
              });
              if (typeof change.selectedType !== 'undefined' && change.selectedType.length !== 0) {
                this.getDonorName(this.state.gridData[index].selectedType, this.state.gridData[index].id, api_url, index);
              }
            }}
            onClear={({ index }) => {
              this.state.gridData[index] = getDefaultRows(1)[0];
              this.setState({
                gridData: this.state.gridData
              })
            }}
            onDelete={({ index }) => {
              this.setState({
                gridData: this.state.gridData.filter((td, i) => i !== index)
              });
            }}
            onBlur={({ index, data }) => {
              if (this.state.gridData[index].setMdnIdError === false) {
                this.getDonorName(this.state.gridData[index].selectedType, data.donorId, api_url, index);
              }
            }}
          />
        </GlobalStyles>
        <MultipleDonorGridFooter currencyCode={currencyCode} amount={""} rows={this.state.gridData} />
      </Container>
    );
  }
}

export default MultipleDonor;