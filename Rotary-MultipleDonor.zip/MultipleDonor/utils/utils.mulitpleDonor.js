export const getDefaultRows = count => {
  const arr = new Array(count);
  return arr.fill({
    id: "",
    name:"",
    amount: "",
    selectedType: "",
    isAutoInserted: true,
    error: false,
    errorMessage: [],
    isLoading: false,
    setMdnIdError: false,
    setMdnAmountError: false,
  });
};
 
export const typeOptions = [
  { label: 'Alumni Association', value: 'Alumni Association' },
  { label: 'Associate Foundation', value: 'Associate Foundation' },
  { label: 'Business', value: 'Business' },
  { label: 'Charitable Organization', value: 'Charitable Organization' },
  { label: 'Club & District Foundation', value: 'Club & District Foundation' },
  { label: 'District', value: 'District' },
  { label: 'Educational', value: 'Educational' },
  { label: 'GB&I', value: 'GB&I'},
  { label: 'Individual', value: 'Individuals' },
  { label: 'Interact Club', value: 'Interact Club' },
  { label: 'Multi-District', value: 'Multi-District' },
  { label: 'Official Licensee', value: 'Official Licensee' },
  { label: 'RCC', value: 'RCC' },
  { label: 'RI', value: 'RI' },
  { label: 'Rotaract Club', value: 'Rotaract Club' },
  { label: 'Rotary Club', value: 'Rotary Club' },
  { label: 'Zone', value: 'Zone' },
];