import React from "react";
import TextInput from 'Form/components/TextInput';
import Select from 'Form/components/Select';
import styled from 'styled-components';
import throbber from '!!url-loader!assets/throbber.gif';
import { typeOptions } from '../../utils/utils.mulitpleDonor'
import {
  CloseGraphic,
  CloseIcon,
  ButtonWrapper
} from 'globalStyles';

const LoadingVisual = styled.div.attrs({ className: 'react-throbber__visual' })`
  background: url(${throbber}) no-repeat;
  height: 32px;
  margin:-0.3rem auto 0.4rem;
  width: 32px;
`;
const MultipleDonorGridRow = props => {
  const {
    multipleDonorConfig,
    gridRowData,
    rowsCount,
    onChange,
    onClear,
    onDelete,
    onBlur
  } = props;
  let topErrorBorder = '';

  if (gridRowData.error || gridRowData.setMdnIdError || gridRowData.setMdnAmountError) {
    topErrorBorder = ' top-error-border';
  }

  return (
    <div className={(gridRowData.error || gridRowData.setMdnIdError || gridRowData.setMdnAmountError) ? "no-top-border" : "row-container"}>
      <div className={"mdg-row flex-host" + topErrorBorder}>
        <div className="mdg-col data">
          <Select
            id="type"
            options={typeOptions}
            value={gridRowData.selectedType}
            onChange={(event) => {
              onChange({ selectedType: event.value });
            }}
          />
        </div>
        <div className="mdg-col data">
          {gridRowData.selectedType ?
            <div className={(gridRowData.error || gridRowData.setMdnIdError) ? 'mdg-error-border-id' : ''}>
              <TextInput
                maxLength="12"
                value={gridRowData.id}
                type="text"
                onChange={event => {
                  onChange({ id: event.target.value });
                }}
                onBlur={event => {
                  onBlur({ donorId: event.target.value.trim() });
                }}
              />
            </div> :
            <label></label>}
        </div>
        <div className="mdg-col data" title={(typeof gridRowData.name != "undefined") ? gridRowData.name : ""}>
          <label>
            {gridRowData.isLoading ? <LoadingVisual /> : (typeof gridRowData.name != "undefined") ? gridRowData.name : ""}
          </label>
        </div>
        <div className="mdg-col data">
        <div className={(gridRowData.setMdnAmountError) ? 'mdg-error-border-id' : ''}>
              <TextInput
                value={gridRowData.amount}
                type="text"
                onChange={event => {
                  onChange({ amount: event.target.value });
                }}
              />
          </div>
        </div>
        {!gridRowData.isAutoInserted && (
          <div className="mdg-actions">
            <ButtonWrapper
              onClick={() => {
                if (rowsCount === multipleDonorConfig.minRows) {
                  onClear();
                } else {
                  onDelete();
                }
              }}
            >
              <CloseGraphic><CloseIcon /></CloseGraphic>
            </ButtonWrapper>
          </div>
        )}
      </div>
      {(gridRowData.error || gridRowData.setMdnIdError) && (
        <div className="mdg-error">{gridRowData.errorMessage[0]}</div>
      )}
      {(gridRowData.error || gridRowData.setMdnAmountError) && (
        <div className="mdg-error">{gridRowData.errorMessage[1]}</div>
      )}
    </div>
  );
};

export default MultipleDonorGridRow;